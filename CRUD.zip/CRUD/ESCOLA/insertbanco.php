<?php

include 'conect.php';

$nome = $_POST['nome'];
$escolaridade = $_POST['escolaridade'];
$serie = $_POST['serie'];

//inserindo os dados no Banco

$sql = "INSERT INTO new_table (nome, escolaridade, serie) VALUES ('$nome', '$escolaridade', '$serie')";

if($conexao->query($sql)){
    echo 'Seus dados foram cadastrados com sucesso!!';
}else{
    echo 'Houve algum erro na conexão';
}


?>