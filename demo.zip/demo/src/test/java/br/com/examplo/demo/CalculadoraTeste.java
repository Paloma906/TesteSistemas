package br.com.examplo.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CalculadoraTeste {

    /**
     * 
     */
    @Test
    public void somaDoisNumeros(){
        Calculadora calculadora = new Calculadora();
        int soma = calculadora.soma(10,20);
        System.out.println(soma);
        assertEquals(30, soma);

    }

    @Test
    public void dividaDoisNumeros(){
        Calculadora calculadora = new Calculadora();
        int divisao = calculadora.divisao(20,10);
        System.out.println(divisao);
        assertEquals(2, divisao);
    }

    @Test
    public void subtrairDoisNumeros(){
        Calculadora calculadora = new Calculadora();
        int subtracao = calculadora.subtracao(30,15);
        System.out.println(subtracao);
        assertEquals(15, subtracao);
    }

    @Test
    public void multiplicarDoisNumeros(){
        Calculadora calculadora = new Calculadora();
        int multiplicacao = calculadora.multiplicacao(6,4);
        System.out.println(multiplicacao);
        assertEquals(24, multiplicacao);
    }
  
    
}
